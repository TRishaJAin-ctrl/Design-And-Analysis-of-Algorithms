Files enclosed in this folder :-

PES1UG19CS542_H.h  :- Header File
PES1UG19CS542_C.c  :- Client File
PES1UG19CS542_F.c  :- Implementation File

Command to run the program :-

gcc PES1UG19CS542_H.h PES1UG19CS542_C.c PES1UG19CS542_F.c
./a.out adjacencylist.txt               

(The input file is entered as a command line argument)


Program Logic :- 

The graph is stored as an adjacency list. Since the problem statement requires us to 
print the shortest path from all the vertices to destination, the transpose of the graph
is found. Then the dijkstra's algorithm is implemented by taking the input as the 
transpose of the graph. The priority queue is implemented using Min-Heap. One of the 
fields in the heap's node is predecessor node which is used to output the shortest path.
Finally while printing the path, we use singly linked list to store the vertices on the
shortest path so that it can effectively perform the role of reversing the list of nodes 
on the shortest path so that we can appropriately print the shortest path according to 
the requirement of the problem statement.

Output Format :-

The vertex, the path and the minimum distance is printed (space separated). 