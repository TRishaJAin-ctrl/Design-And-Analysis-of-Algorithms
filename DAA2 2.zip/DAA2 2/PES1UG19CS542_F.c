#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<stdbool.h>
#include "PES1UG19CS542_H.h" 


struct AListNode* newAListNode(int dest, int weight)   //function to create a new node in the adjacency list
{
    struct AListNode* newNode = (struct AListNode*) malloc(sizeof(struct AListNode));
    newNode->dest = dest;
    newNode->next = NULL;
    newNode->weight = weight;
    return newNode;
}

struct Graph* createGraph(int V)  //function to create the graph
{
	struct Graph* graph = (struct Graph*) malloc(sizeof(struct Graph));
    graph->V = V;
    graph->array = (struct AList*) malloc(V * sizeof(struct AList));
    int i;
    for (i = 1; i < V; ++i)  //initialising the adjacency list
        graph->array[i].head = NULL;
    return graph;
}

void addEdge(struct Graph* graph, int src, int dest, int weight)  //function to add a node in the graph
{
    struct AListNode* newNode = newAListNode(dest, weight);  //creating the node
    newNode->next = graph->array[src].head;  //adding the node to the adjacency list
    graph->array[src].head = newNode;  
}

void reverseGraph(struct Graph* graph, struct Graph* transpose)  //function to find the transpose of the graph
{
	int v = graph->V;
	for(int i = 1; i < v; i++)
	{
		struct AListNode* pCrawl = graph->array[i].head;
		while(pCrawl)
		{
			addEdge(transpose, pCrawl->dest, i, pCrawl->weight);  //adding a reverse edge to transpose the graph
			pCrawl = pCrawl->next;	
		}
	}
}

struct MinHNode* newMinHNode(int v, int d, int p)  //function to create a new heap node
{
    struct MinHNode* minHNode = (struct MinHNode*)malloc(sizeof(struct MinHNode));
    minHNode->v = v;
    minHNode->d = d;
    minHNode->p = p;
    return minHNode;
}

struct MinH* createMinH(int capacity)  //function to create a min heap
{
    struct MinH* minH = (struct MinH*)malloc(sizeof(struct MinH));
    minH->pos = (int *)malloc(capacity * sizeof(int));
    minH->size = 0;  //initialising the number of elements in the heap to zero
    minH->capacity = capacity;
    minH->array = (struct MinHNode**)malloc(capacity * sizeof(struct MinHNode*));
    return minH;
}

void swapMinHNode(struct MinHNode** a, struct MinHNode** b)  //function that helps in swapping two nodes
{
    struct MinHNode* t = *a;
    *a = *b;
    *b = t;
}

void minHeapify(struct MinH* minH, int idx)  //function that converts the given heap to a min heap
{
    int smallest, left, right;
    smallest = idx;  
    left = 2 * idx;  //left stores the index to left child of the node
    right = 2 * idx + 1;  //right stores the index to right child of the node
    if (left < minH->size && minH->array[left]->d < minH->array[smallest]->d )
      smallest = left;   //if left has min distance then swap with smallest
    if (right < minH->size && minH->array[right]->d < minH->array[smallest]->d )
      smallest = right;  //if right has min distance then swap with smallest
    if (smallest != idx)
    {
        struct MinHNode *smallestNode = minH->array[smallest];
        struct MinHNode *idxNode = minH->array[idx];
        minH->pos[smallestNode->v] = idx;  
        minH->pos[idxNode->v] = smallest;
        swapMinHNode(&minH->array[smallest], &minH->array[idx]);  //swapping the nodes to make a min heap
        minHeapify(minH, smallest);  //continue swapping by calling the function with the new 'smallest'
    }
}

int isEmpty(struct MinH* minH)  //function to check if the heap is empty
{
    return minH->size == 0;
}

struct MinHNode* extractMin(struct MinH* minH)  //function to return the minimum distance vertex
{
    if (isEmpty(minH))
        return NULL;
    struct MinHNode* root = minH->array[1];
    struct MinHNode* lastNode = minH->array[minH->size];
    //swaps the last element with the first element
    minH->array[1] = lastNode;
    minH->array[minH->size] = root;
    minH->pos[root->v] = minH->size;
    minH->pos[lastNode->v] = 1;
    --(minH->size);  //size of the heap is reduced because the smallest distance element is extracted
    minHeapify(minH, 1);  //min heap needs to be reconstructed because one node is deleted
    return root;  //return the minimum distance vertex
}

void decreaseKey(struct MinH* minH, int v, int d)  //function to decrease the distance value of vertex
{
    int i = minH->pos[v];  //i -> index of the vertex v in heap 
    minH->array[i]->d = d;  //sets the new distance value for vertex v
    if((i/2) <= 0)  //if parent doesn't exist for vertex v i.e. if v = root
        return;
    while (i && minH->array[i]->d < minH->array[i / 2]->d)
    {
    	//swapping the child with the parent if child's distance is smaller than the parent's distance 
        minH->pos[(minH->array[i])->v] = i/2;
        minH->pos[(minH->array[i/2])->v] = i;
        swapMinHNode(&minH->array[i], &minH->array[i / 2]); 
        i = i / 2;   //moving up the heap to the parent of the node
        if((i/2) <= 0)  //if v = root then return from the function
        	return;
    }
}

bool isInMinHeap(struct MinH *minH, int v)  //returns true if element present in the heap
{
   if(minH->pos[v] <= minH->size)
		return true;
   return false;
}

//recursive function to print the shortest path
void printPath(struct MinHNode* j, struct MinH* minH, struct Node** head)
{
    if (j->p==-1)  //if j is source vertex
        return;
    //call the function on the predecessor of the node j    
    printPath(minH->array[minH->pos[j->p]], minH, head); 
    struct Node* new = (struct Node*)malloc(sizeof(struct Node));  //create a new node
    new->n = j->v;   
    new->next = NULL;
    if(*head == NULL){
    	*head = new;   //if no node present in the list
    }
    else{
    	new->next = *head;   //inserting node at the front of the list
    	*head = new;
    }
    
}
 
void printSolution(int dist[], struct MinH* minH, int src)  //calls the print path function for all the vertices
{
    for (int i = 1; i < minH->capacity - 1; i++)
    {
        if(dist[i] == INT_MAX){   //this would indicate that no path exists from source to this vertex
        	printf("%d NO PATH\n",i);
        	break;
        }
        printf("%d ",minH->array[minH->pos[i]]->v);  //prints vertex value
        struct Node* head = NULL;
        printPath(minH->array[minH->pos[i]], minH, &head);  //calls the print path function for the vertex
        while(head)  //prints the path
        {
        	printf("%d ", head->n);
        	head = head->next;
        }
        printf("%d %d\n",src, dist[i]);  //prints the minimum distance
    }
}

void dijkstra(struct Graph* graph, int src)  //function implements the dijkstra's algorithm to find the shortest path
{
    int V = (graph->V)-1;  //number of vertices in the graph
    int dist[V+1];  //stores the distance values from source to the vertex
    struct MinH* minH = createMinH(V+1);  //create a min heap for the number of vertices
    
    for (int v = 1; v <= V; ++v)
    {
        dist[v] = INT_MAX;  //initialise distance value of all vertices
        minH->array[v] = newMinHNode(v, dist[v], -1);   //create a node for each vertex in the heap
        minH->pos[v] = v;  //initialise positions of all the vertices
    }
    
    minH->array[src] = newMinHNode(src, dist[src], -1);
    minH->pos[src] = src;
    dist[src] = 0;  //distance value of source vertex is made zero so that it is extracted first
    decreaseKey(minH, src, dist[src]);
    
    minH->size = V;   //size of min heap is initialised to the total number of vertices in the graph

    while (!isEmpty(minH))
    {
        struct MinHNode* minHNode = extractMin(minH);  //vertex with minimum distance value is extracted
    
        int u = minHNode->v; //vertex number of extracted vertex is stored in u
 
		//all the adjacent vertices of the graph are traversed and their distance value is calculated 
        struct AListNode* pCrawl = graph->array[u].head;  
        while (pCrawl != NULL)
        {
            int v = pCrawl->dest;
            // if distance of v through u is less than its previously stored distance
            if (isInMinHeap(minH, v) && dist[u] != INT_MAX && pCrawl->weight + dist[u] < dist[v])
            {
                dist[v] = dist[u] + pCrawl->weight;  //newly calculated distance
 				(minH->array[minH->pos[v]])->p = u;  //saving the predecessor vertex of the vertex v
                decreaseKey(minH, v, dist[v]);  //updating distance value in min heap
            }
            pCrawl = pCrawl->next;  //move to the next adjacent node
        }
    }
    printSolution(dist, minH, src);  //function called to print the shortest distance
}