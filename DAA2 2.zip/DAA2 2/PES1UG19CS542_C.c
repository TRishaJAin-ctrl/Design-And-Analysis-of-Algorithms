#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<stdbool.h>
#include "PES1UG19CS542_H.h" 

int main(int argc, char* argv[])
{
	FILE *fptr;
	fptr = fopen(argv[1],"r");
	if(fptr == NULL)
   	{
    	printf("Error in opening the file!\n");   
    	exit(1);             
   	}
	int V;  //stores the number of vertices
	fscanf(fptr, "%d", &V);
	struct Graph* graph = createGraph(V+1);  //creates a graph with V vertices
	struct Graph* transpose = createGraph(V+1);   //finds the transpose of the graph and stores it in transpose
	int src, dest, weight;
	for(int i = 0 ; i < V; i++)
	{
		while(fscanf(fptr, "%d",&src)!=EOF)  
		{
			while(fscanf(fptr, "%d %d",&dest,&weight)!= EOF)
			{
				addEdge(graph, src, dest, weight);
				char ch;
				fscanf(fptr, "%c",&ch);
				if(ch == '\n')
					break;
			}
		}
	}
	reverseGraph(graph,transpose);  //entered graph is reversed and stored in transpose
	dijkstra(transpose,V);  //dijkstra's algorithm is applied to the transposed graph
	fclose(fptr);
	return 0;
}