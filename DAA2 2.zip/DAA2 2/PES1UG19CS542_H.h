#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<stdbool.h>

struct AListNode{
	int dest;    //value of the node
	int weight;   //weight of the edge connecting the node and its predecessor node
	struct AListNode* next;   //pointer to the next node in graph
};

struct AList{
	struct AListNode* head;  //head of the list
};

struct Graph{
	int V;  //number of vertices in the graph
	struct AList* array;   //adjacency list representation of graph
};

struct MinHNode
{
    int  v;  //value of the node
    int d;  //distance of the node from the source
    int p;   //predecessor of the node on the path from source to the vertex
};

struct MinH
{
    int size;  //number of elements in the heap
    int capacity;   //total number of elements that can be present in the heap
    int *pos;   //used to keep track of the position of the vertex in the heap
    struct MinHNode **array;  //used to store the elements in the heap
};

//this structure is used to reverse the path
struct Node   //structure of a singly linked list node
{  
	int n;  //value of the node 
	struct Node* next;   //pointer to the next node in the list
};

struct AListNode* newAListNode(int, int);   //function to create a new node in the adjacency list

struct Graph* createGraph(int);  //function to create the graph

void addEdge(struct Graph*, int, int, int);  //function to add a node in the graph

void reverseGraph(struct Graph*, struct Graph*);  //function to find the transpose of the graph

struct MinH* createMinH(int);  //function to create a min heap

void swapMinHNode(struct MinHNode**, struct MinHNode**);  //function that helps in swapping two nodes

void minHeapify(struct MinH*, int);  //function that converts the given heap to a min heap

int isEmpty(struct MinH*);  //function to check if the heap is empty

struct MinHNode* extractMin(struct MinH*);  //function to return the minimum distance vertex

void decreaseKey(struct MinH*, int, int);  //function to decrease the distance value of vertex

bool isInMinHeap(struct MinH *, int);  //returns true if element present in the heap

//recursive function to print the shortest path
void printPath(struct MinHNode*, struct MinH*, struct Node**);

void printSolution(int*, struct MinH*, int);  //calls the print path function for all the vertices

void dijkstra(struct Graph*, int);  //function implements the dijkstra's algorithm to find the shortest path