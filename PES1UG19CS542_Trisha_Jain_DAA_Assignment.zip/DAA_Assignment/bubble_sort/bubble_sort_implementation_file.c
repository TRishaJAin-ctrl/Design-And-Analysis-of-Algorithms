//IMPLEMENTATION FILE FOR BUBBLE SORT

#include "bubble_sort_header_file.h"
long long int count = 0;

int bubble_sort(int* a)
{
   	for (int i = 0; i < MAX - 1; i++)   
   	{       
       for (int j = 0; j < MAX - i - 1; j++)
       {  
           	count++;
           	if (a[j] > a[j+1]) 
        	{
        	 	int temp = a[j];
        	 	a[j] = a[j + 1];
        	 	a[j + 1] = a[j];
        	 }
        }
    }
    return count;
}     