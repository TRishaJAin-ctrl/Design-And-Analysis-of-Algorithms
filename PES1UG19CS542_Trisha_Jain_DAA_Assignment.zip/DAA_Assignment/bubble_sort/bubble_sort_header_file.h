//HEADER FILE FOR BUBBLE SORT

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 900000
extern long long int count;

int bubble_sort(int*);