//HEADER FILE FOR QUICK SORT

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 950000

extern long long int count;

void quick_sort(int*, int, int);
int partition(int*, int, int);