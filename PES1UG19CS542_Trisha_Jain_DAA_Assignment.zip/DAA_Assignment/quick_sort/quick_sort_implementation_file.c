//IMPLEMENTATION FILE FOR QUICK SORT

#include "quick_sort_header_file.h"

long long int count = 0;
void quick_sort(int* a, int low, int high)
{
	if(low < high)
	{	
		int j = partition(a, low, high);
		quick_sort(a, low, j - 1);
		quick_sort(a, j + 1, high);
	}
}

int partition(int* a, int  low, int high)
{
	int pivot = a[low];
	int i = low + 1;
	int j = high;
	while(i < j)
	{
		while(i <= high && a[i] <= pivot){
			i++;
			count++;
		}
		while(j > low && a[j] >= pivot){
			j--;
			count++;
		}
		if(i < j)
		{
			int temp = a[i];
			a[i] = a[j];
			a[j] = temp;
		}
	}
	if(j != low)
	{
		a[low] = a[j];
		a[j] = pivot;
	}
	return j;
}