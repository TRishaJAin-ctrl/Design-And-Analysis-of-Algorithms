//CLIENT FILE FOR QUICK SORT

#include "quick_sort_header_file.h"

int main()
{
	int a[MAX];
	clock_t start, end;
	for(int i = 0; i < MAX; i++)
	{
		a[i] = rand();
	}
	/*for(int i = 0; i < MAX; i++)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
	*/
	start = clock();
	quick_sort(a, 0, MAX - 1);
	end = clock();
	
	FILE *fptr;
	fptr = fopen("quick_sort_output_file_time_taken","a");
	fprintf(fptr, "%d,", MAX);
	fprintf(fptr, "%f\n", (float)(end-start)/CLOCKS_PER_SEC);
	fclose(fptr);
	
	
	FILE *fptr1;
	fptr1 = fopen("quick_sort_output_file_number_of_comparisons","a");
	fprintf(fptr1, "%d,", MAX);
	fprintf(fptr1, "%lld\n", count);
	fclose(fptr1);
	
	return 0;
}