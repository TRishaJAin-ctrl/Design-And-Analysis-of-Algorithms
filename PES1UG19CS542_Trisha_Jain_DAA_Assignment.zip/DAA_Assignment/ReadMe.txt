The programs for the four algorithms are placed in four separate folders along with their 
respective output files.

The sorting algorithms are implemented using client, implementation and header files.

The commands to run the files are :-
gcc selection_sort_client_file.c selection_sort_header_file.h selection_sort_implementation_file.c
./a.out

gcc bubble_sort_client_file.c bubble_sort_header_file.h bubble_sort_implementation_file.c
./a.out

gcc merge_sort_client_file.c merge_sort_header_file.h merge_sort_implementation_file.c
./a.out

gcc quick_sort_client_file.c quick_sort_header_file.h quick_sort_implementation_file.c
./a.out


NOTE:- To make the files run over different input sizes the MAX variable in the header file needs to be edited.


The graphs are titled as follows:-

Element comparisons for selection sort and bubble sort :- element_comparison_bubble_selection.png

Element comparisons for merge sort and quick sort :- element_comparison_merge_quick.png

Time taken for sorting by selection sort and bubble sort :- time_bubble_selection.png

Time taken for sorting by merge sort and quick sort :- time_merge_quick.png



The output files are titled as follows:-

bubble_sort_output_file_number_of_comparisons.txt
bubble_sort_output_file_time_taken.txt

selection_sort_output_file_number_of_comparisons.txt
selection_sort_output_file_time_taken.txt

merge_sort_output_file_number_of_comparisons.txt
merge_sort_output_file_time_taken.txt

quick_sort_output_file_number_of_comparisons.txt
quick_sort_output_file_time_taken.txt