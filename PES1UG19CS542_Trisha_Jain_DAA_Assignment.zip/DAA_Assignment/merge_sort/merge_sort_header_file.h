//HEADER FILE FOR MERGE SORT

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 950000
extern long long int count;

void merge_sort(int*, int, int);
void merge(int*, int, int, int);