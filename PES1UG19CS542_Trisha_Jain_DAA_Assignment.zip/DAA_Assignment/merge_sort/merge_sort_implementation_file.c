//IMPLEMENTATION FILE FOR MERGE SORT

#include "merge_sort_header_file.h"

long long int count = 0;
void merge_sort(int* a, int low, int high)
{
	if(low < high)
	{
		int mid = (low + high)/2;
		merge_sort(a, low, mid);
		merge_sort(a, mid + 1, high);
		merge(a, low, mid, high);
	}
}

void merge(int* a, int low, int mid, int high)
{
	int i = low;
	int b[MAX];
	int j = mid + 1;
	int k = 0;
	while(i <= mid && j <= high)
	{
		if(a[i] < a[j])
		{
			b[k++] = a[i];
			i++;
		}
		else
		{
			b[k++] = a[j];
			j++;
		}
		count++;
	}
	while(i <= mid)
	{
		b[k++] = a[i];
		i++;
	}
	while(j <= high)
	{
		b[k++] = a[j];
		j++;
	}
	int l = low;
	for(i = 0; i < k; i++)
	{
		a[l++] = b[i];
	}
} 