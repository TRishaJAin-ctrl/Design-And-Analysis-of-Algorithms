//CLIENT FILE FOR SELECTION SORT

#include "selection_sort_header_file.h"

int main()
{
	int a[MAX];
	long long int num_of_comparisons;
	clock_t start, end;
	for(int i = 0; i < MAX; i++)
	{
		a[i] = rand();
	}
	/*for(int i = 0; i < MAX; i++)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
	*/
	start = clock();
	num_of_comparisons = selection_sort(a);
	end = clock();
	/*for(int i = 0; i < MAX; i++)
	{
		printf("%d ", a[i]);
	}
	printf("\n");
	*/
	FILE *fptr;
	fptr = fopen("selection_sort_output_file1_time_taken","a");
	fprintf(fptr, "%d,", MAX);
	fprintf(fptr, "%f\n", (float)(end-start)/CLOCKS_PER_SEC);
	fclose(fptr);
	
	
	FILE *fptr1;
	fptr1 = fopen("selection_sort_output_file1_number_of_comparisons","a");
	fprintf(fptr1, "%d,", MAX);
	fprintf(fptr1, "%lld\n", count);
	fclose(fptr1);
	/*printf("The total time taken to perform selection sort for %d elements is %f\n", MAX, (float)(end-start)/CLOCKS_PER_SEC);
	printf("The number of element to element comparisons for %d elements = %lld\n", MAX, num_of_comparisons);
	*/return 0;
}

