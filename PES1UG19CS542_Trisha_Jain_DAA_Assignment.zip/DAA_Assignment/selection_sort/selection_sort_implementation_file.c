//IMPLEMENTATION FILE FOR SELECTION SORT

#include "selection_sort_header_file.h"
long long int count = 0;

int selection_sort(int* a)
{
	for(int i = 0; i < MAX - 1 ;i++)
	{
		int mp = i;
		for(int j = mp + 1; j < MAX; j++)
		{
			count++;
			if(a[j] < a[mp])
			{
				mp = j;
			}
		}
		if(mp != i)
		{
			int temp = a[mp];
			a[mp] = a[i];
			a[i] = temp;
		}
	}
	return count;
} 