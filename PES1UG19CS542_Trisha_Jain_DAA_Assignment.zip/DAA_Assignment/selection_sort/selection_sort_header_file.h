//HEADER FILE FOR SELECTION SORT

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#define MAX 1000000
extern long long int count;

int selection_sort(int*);